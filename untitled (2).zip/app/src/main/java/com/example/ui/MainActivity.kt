package com.example.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.R
import com.example.demo.MeteorDodgeActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btn_open_accessibility)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btn_open_overlay)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }

        findViewById<Button>(R.id.btn_start_capture)?.setOnClickListener {
            // Screen capture intent mapping later
        }

        findViewById<Button>(R.id.btn_launch_demo)?.setOnClickListener {
            startActivity(Intent(this, MeteorDodgeActivity::class.java))
        }

        findViewById<Button>(R.id.btn_open_settings)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}
